# Recursos visuales

## Arquitectura Forma

Archivo: `public/images/architecture.webp`, 1600 × 900. Generado mediante la herramienta integrada Imagegen, sin usar API o CLI. Edificio ficticio; se presenta como concepto propio, no como fotografía de un proyecto construido.

Prompt final utilizado:

> Use case: photorealistic-natural. Asset type: architectural image for an original conceptual architecture website inside the AM Studio website. A striking monumental brutalist concrete gallery overlooking still water, a large cantilever horizontal volume and a single deeply shadowed cylindrical arch, precise exposed pale grey concrete with subtle grain, silver olive tree, quiet horizon. Architectural editorial photography, monochrome black and white, sharp geometric shadows, soft atmospheric sky, sophisticated composition, 35mm architectural tilt-shift lens. Wide landscape composition. No people, no text, no watermark, no logos. It is a fictional architecture concept, not an existing building. Save the image and return its local file path.

## Capturas e interfaces

Todos los mockups e interfaces son componentes originales del sitio. `forma-page.webp`, `forma-layer-*.webp` y el manifiesto geométrico se generan con Playwright desde `/demo/forma`. No son capturas de un cliente ni de terceros.

## Fuentes

Geist e Instrument Serif: Google Fonts, alojadas localmente. Licencias OFL incluidas junto a los archivos WOFF2 en `public/fonts`.

## Redes

Trazados de Instagram, TikTok y WhatsApp: Simple Icons, obtenidos del repositorio [simple-icons](https://github.com/simple-icons/simple-icons). Licencia incluida en `public/icons/LICENSE.md`. Los nombres y marcas pertenecen a sus respectivos titulares.

## Marca AM

Logo oficial suministrado por el propietario el 9 de noviembre de 2026. `public/brand/am-logo-original.png` conserva el PNG recibido sin cambios. `am-logo.svg` incrusta ese original y recorta solamente el espacio vacío mediante su viewBox; no redibuja ni deforma el monograma. Se utiliza en navegación, footer, presentación del estudio, recorrido 3D, favicon y vista previa social. `src/config/brand.ts` centraliza su ruta.
