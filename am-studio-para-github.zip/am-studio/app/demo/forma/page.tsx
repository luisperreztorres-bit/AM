import {InterfacePreview} from '../../../src/components/SitePage';
export default function FormaCapture(){return <main className="capture-page"><InterfacePreview full/></main>;}
