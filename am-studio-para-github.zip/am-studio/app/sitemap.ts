import {brand} from '../src/config/brand';
export default function sitemap(){return ['','/servicios','/proyectos','/experiencia','/nosotros','/contacto','/privacidad',...brand.projects.map(p=>'/proyectos/'+p.slug)].map(path=>({url:brand.website+path,changeFrequency:'monthly' as const,priority:path?0.7:1}));}
