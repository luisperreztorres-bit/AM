import {brand} from '../src/config/brand';
export default function robots(){return {rules:{userAgent:'*',allow:'/',disallow:'/api/'},sitemap:brand.website+'/sitemap.xml'};}
