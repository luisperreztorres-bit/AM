import {getDb} from '../../../db';
import {inquiries} from '../../../db/schema';
import {z} from 'zod';
const schema=z.object({name:z.string().trim().min(1).max(100),business:z.string().trim().min(1).max(150),email:z.string().trim().email().max(254),phone:z.string().trim().max(25).refine(v=>!v||/^[+0-9 ()-]{7,25}$/.test(v),'Teléfono inválido').optional(),pageType:z.enum(['Web corporativa','Landing page','Experiencia a medida','Quiero orientación']),budget:z.string().trim().max(100).optional(),description:z.string().trim().min(20).max(5000),consent:z.literal('yes'),website:z.string().max(0).optional()});
export async function POST(request:Request){
  const origin=request.headers.get('origin');if(!origin||origin!==new URL(request.url).origin)return Response.json({error:'Solicitud no permitida.'},{status:403});
  if(!request.headers.get('content-type')?.includes('application/json'))return Response.json({error:'Formato no permitido.'},{status:415});
  if(Number(request.headers.get('content-length')||0)>20000)return Response.json({error:'La solicitud es demasiado extensa.'},{status:413});
  try{const text=await request.text();if(text.length>20000)return Response.json({error:'La solicitud es demasiado extensa.'},{status:413});const parsed=schema.safeParse(JSON.parse(text));if(!parsed.success)return Response.json({error:'Revisa los campos: nombre, negocio, correo, tipo de página, descripción de al menos 20 caracteres y consentimiento.'},{status:400});
    const id='AM-'+crypto.randomUUID().slice(0,8).toUpperCase();const {consent,website,...data}=parsed.data;void consent;void website;
    await getDb().insert(inquiries).values({...data,id,createdAt:Date.now()});
    return Response.json({id},{status:201,headers:{'Cache-Control':'no-store'}});
  }catch{ return Response.json({error:'No pudimos guardar tu solicitud. Intenta nuevamente o contáctanos por WhatsApp.'},{status:503}); }
}
