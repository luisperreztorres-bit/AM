import type { Metadata, Viewport } from 'next';
import './globals.css';
import './refinement.css';
import { brand } from '../src/config/brand';
export const metadata: Metadata = {
  metadataBase: new URL(brand.website),
  title: { default: 'AM Studio — Tu idea, en marcha.', template: '%s · AM Studio' },
  description: 'Diseñamos y desarrollamos páginas web profesionales para negocios. Diseño cuidado, experiencias claras y desarrollo a medida.',
  openGraph: { title: 'AM Studio — Tu idea, en marcha.', description: 'Experiencias digitales a la altura de tu negocio.', locale: 'es_MX', type: 'website', images: ['/og.png'] },
  twitter: { card: 'summary_large_image' }, robots: { index: true, follow: true }, icons: { icon: '/favicon.svg' },
  alternates: {canonical:'/'},
};
export const viewport:Viewport={width:'device-width',initialScale:1,viewportFit:'cover',themeColor:'#0a0a0a'};
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="es" data-type="service"><head><meta name="page-type" content="service"/><meta name="site-kind" content="other"/><link rel="preload" as="font" type="font/woff2" href="/fonts/geist-latin.woff2" crossOrigin="anonymous"/><link rel="preload" as="font" type="font/woff2" href="/fonts/instrument-serif-italic.woff2" crossOrigin="anonymous"/></head><body>{children}</body></html>; }
