import { SitePage } from '../src/components/SitePage';
export default function Home() { return <SitePage route="/" />; }
