import { notFound, redirect } from 'next/navigation';
import type { Metadata } from 'next';
import { SitePage } from '../../src/components/SitePage';
const titles: Record<string,string> = {'/servicios':'Diseño y desarrollo web','/proyectos':'Proyectos y conceptos','/proyectos/forma':'Forma — concepto de arquitectura','/experiencia':'Experiencia AM','/nosotros':'Sobre AM','/contacto':'Hablemos de tu proyecto','/privacidad':'Privacidad'};
export async function generateMetadata({params}:{params:Promise<{slug:string[]}>}):Promise<Metadata>{const {slug}=await params; const route='/'+slug.join('/');return {title:titles[route] || 'Página no encontrada',alternates:{canonical:route},description:titles[route] ? `${titles[route]}. AM Studio: diseño y desarrollo de páginas web profesionales para negocios.` : undefined};}
export default async function Page({params}:{params:Promise<{slug:string[]}>}){const {slug}=await params;const route='/'+slug.join('/');if(route==='/proyectos/interface-lab')redirect('/experiencia');if(!titles[route])notFound();return <SitePage route={route}/>;}
