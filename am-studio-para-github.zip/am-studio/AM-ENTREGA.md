# AM Studio — entrega de desarrollo

> Documento histórico de la primera versión. La entrega vigente, con el logo oficial, el rediseño y los apartados retirados por el propietario, está en [docs/REDISENO-ENTREGA.md](docs/REDISENO-ENTREGA.md). Las notas siguientes describen la versión inicial y sus pendientes de entonces.

Sitio en español construido con React 19, TypeScript y rutas App Router compatibles con Next.js, ejecutadas mediante Vinext en Cloudflare Workers / Sites. CSS propio, fuentes locales, Three.js con carga diferida y base de datos D1. No se instalaron bibliotecas de animación redundantes.

## Ejecutar

Requiere Node 22.13 o superior. `npm ci`, `npm run dev` y abrir la URL local impresa. `npm run build` genera el Worker y los assets. `npx tsc --noEmit` comprueba los tipos. `node scripts/qa.mjs` ejecuta la revisión Playwright contra `http://127.0.0.1:5173`; puede usarse `AM_TEST_URL` para otra URL local.

Para el formulario en desarrollo, después del primer build, ejecutar una sola vez:

```powershell
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_funny_richard_fisk.sql
```

No volver a ejecutar una migración aplicada. Las migraciones de producción se aplican al publicar mediante Sites. La base local y la publicada son independientes.

## Editar la marca

`src/config/brand.ts` centraliza nombre, lema, propuesta, logo, redes, WhatsApp, correo, ubicación, servicios y proyectos. `logo` admite una ruta a un archivo dentro de `public/`. Actualmente es `null`: el nombre tipográfico AM Studio es provisional, no una reconstrucción del logo oficial.

Instagram: `https://www.instagram.com/____amstudio.pue/`.

TikTok: `https://www.tiktok.com/@am.estudio_`.

WhatsApp: `522221055229`. El helper genera un enlace `wa.me` con mensaje codificado. Los canales aparecen en contacto y footer y abren en otra pestaña. Instagram y TikTok impidieron comprobar automáticamente la disponibilidad de sus perfiles; se conservaron las URLs suministradas.

## Rutas y contenido

- `/`: portada, filosofía, servicios, recorrido 3D, conceptos, laboratorio, proceso, responsive, preguntas y CTA.
- `/servicios`, `/proyectos`, `/experiencia`, `/nosotros`, `/contacto`, `/privacidad`.
- `/proyectos/forma`, `/proyectos/interface-lab`: casos de estudio de conceptos propios, identificados como tales.
- `/demo/forma`: documento de captura para texturas del recorrido. No es un proyecto de cliente.
- `/api/contact`: solo POST, validación del servidor, consentimiento, origen, tamaño y honeypot. No expone consultas públicas.

No hay testimonios, clientes, resultados, precios, plazos ni ubicación comercial inventados. Mofles Yáñez aparece únicamente como caso pendiente de validación.

## Solicitudes de contacto

Se guardan en la tabla D1 `inquiries`, con referencia y fecha. La interfaz confirma únicamente cuando D1 termina de guardar. El estado de error permite reintentar; WhatsApp es un canal alternativo. Esta versión no envía notificaciones de correo porque no se proporcionó un correo ni proveedor autorizado. Las solicitudes pueden revisarse mediante las herramientas de base de datos de Sites o el acceso autorizado a D1. No se implementó un panel público de datos personales.

## Animación y captura

`src/animation/flyover.ts` contiene funciones puras de cámara e integración de velocidad. `window.amFlyover.seek(t)` evalúa la escena en un tiempo exacto de 0 a 14.5 segundos. El recorrido admite reproducción, pausa, reinicio, scrubbing y vinculación voluntaria al scroll. Three.js se importa cuando el contenedor se aproxima al viewport. No renderiza la escena cuando está fuera de pantalla o la pestaña está oculta. En móvil limita la resolución y desactiva sombras; si falla WebGL, muestra el mockup HTML.

La página de captura usa 1440 px y DPR 2. Playwright captura la página y tres capas con `data-layer`, sus posiciones y dimensiones en `public/images/forma-layers.json`. Las capas son archivos independientes. Texturas WebP con mipmaps y anisotropía. El postprocesado de profundidad de campo por píxel y el motion blur por subframes no están habilitados en la web interactiva.

Motion Lab transforma el mismo contenedor entre trece estados y admite demo pausada, controles reales, slider, switch, pestañas, muestras de gráfica, filtro de comandos y notificaciones. Sus valores son ejemplos y el reproductor no emite audio. La demo responsive usa el mismo DOM y consultas de contenedor reales.

No se incluyen exportaciones MP4 en esta entrega. Las experiencias funcionan en el sitio, y el recorrido dispone de evaluación determinista para una exportación posterior.

## Diseño y accesibilidad

Paleta: fondo `#08090B`, papel `#F9FBFB`, texto `#111216`, secundario `#686B70`, línea `#DFE1E1`, acento puntual `#F26442`. Tipografías locales Geist variable e Instrument Serif Italic. El acento señala el estado de marca y los focos. La firma visual es la interfaz arquitectónica en perspectiva; el resto del sitio mantiene un ritmo editorial.

Se aplicaron las referencias reales instaladas de Apple Design sobre jerarquía, accesibilidad, layout, tipografía, color, movimiento, botones y entrada de datos. No se encontró el ZIP mencionado en el brief. Hay navegación semántica, enlace para saltar al contenido, foco visible, etiquetas, mensajes de estado, controles nativos y adaptación a `prefers-reduced-motion`. Las escenas no bloquean la navegación ni la lectura.

## QA

Playwright: 36 comprobaciones principales y 17 adicionales de páginas internas y teclado, incluyendo 1440, 1280, 768, 390 y 360 px sin overflow, ocho rutas, títulos, navegación móvil, formulario y persistencia local real, rechazo de datos inválidos, redes, sliders, switch, tabs, command palette y trayectoria sin inversiones. Capturas en la carpeta hermana `am-studio-qa`. También se revisaron visualmente los frames 0, 1.6, 2.5, 5, 6.5, 9.3 y 11 s. No equivale a una auditoría WCAG completa ni a una medición de Core Web Vitals con tráfico real.

## Pendientes del propietario

1. Archivo del logo oficial para sustituir el nombre provisional y las iniciales de las tarjetas de demostración.
2. Recursos autorizados y validación de Mofles Yáñez y otros trabajos reales.
3. Identidad legal, domicilio, correo de privacidad, retención y validación del aviso. `/privacidad` se identifica como borrador pendiente de revisión.
4. Correo comercial, ubicación y proveedor de notificaciones, si se necesitan. No se publicaron datos no suministrados.

## Publicación y Vercel

El destino preparado y probado es Sites / Cloudflare Workers. `.openai/hosting.json` conserva la identidad del sitio y el binding `DB`. No publicar tokens, archivos `.env`, `.wrangler` ni la base local.

Para una migración a Vercel, usar el mismo código App Router con Next.js y cambiar los scripts a `next dev`, `next build` y `next start`; configurar el proyecto en Vercel con preset Next.js. Antes de desplegar allí se debe sustituir `db/index.ts` (que importa `cloudflare:workers`) por un adaptador de base de datos compatible con Vercel y aplicar la misma migración. El Worker, los bindings y los plugins de Vite son específicos de Cloudflare y no forman parte del build de Vercel. Actualizar `brand.website` al dominio definitivo y repetir las pruebas. No se afirma que el backend D1 actual funcione directamente en Vercel.

## Assets

La imagen arquitectónica de Forma es un recurso original generado con la herramienta integrada Imagegen. Prompt final: fotografía editorial monocromática de una galería brutalista conceptual de concreto junto al agua, volumen en voladizo, arco sombreado y olivo; sin personas, marcas ni texto. Se convirtió a WebP (1600 × 900, aproximadamente 144 KB). No representa un edificio construido. Los iconos de redes provienen de Simple Icons y mantienen sus trazados. Las fuentes se descargaron de Google Fonts para servirlas localmente; se incluyen las licencias OFL.
