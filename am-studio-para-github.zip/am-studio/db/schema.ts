import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const inquiries=sqliteTable('inquiries',{
  id:text('id').primaryKey(), name:text('name').notNull(), business:text('business').notNull(),
  email:text('email').notNull(), phone:text('phone'), pageType:text('page_type').notNull(),
  budget:text('budget'), description:text('description').notNull(), createdAt:integer('created_at').notNull(),
});
