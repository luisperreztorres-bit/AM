# AM Studio — entrega vigente

Sitio: https://am-studio-digital-261110.axialkelp1.chatgpt.site

Se conserva el mismo proyecto de Sites, su acceso privado y el backend D1. El punto anterior está en el tag `am-before-refinement-20261109`. Las capturas y los informes están en la carpeta de entrega hermana `am-studio-redesign`.

## Cambios visibles

- Logo oficial incorporado al encabezado, footer, presentación del estudio, recorrido 3D, favicon y vista previa social. Se preserva el PNG original; el SVG únicamente recorta el margen vacío, sin redibujar el monograma.
- Apartado de Mofles Yáñez retirado por indicación posterior del propietario. También se retira “Interfaces que responden”, sus demostraciones y enlaces. La antigua URL `/proyectos/interface-lab` redirige a `/experiencia`.
- Hero con laptop y móvil que muestran una interfaz original; el selector cambia realmente la presentación. Forma se identifica como concepto del estudio y es el único proyecto visible.
- Sistema monocromático, tipografía Geist y un contraste serif reservado. Servicios con una vista propia por opción, proceso editorial y demostración responsive funcional.
- Recorrido 3D conservado con pausa, reinicio, control temporal, movimiento reducido y suspensión fuera de pantalla. Las tarjetas usan el logo suministrado.
- Menú móvil con gestión de foco y Escape. Formulario con errores asociados a los campos, conservación de datos al fallar y confirmación solo después de guardar en D1. Contactos y redes oficiales conservados.

## Skills instaladas

Instalación local al proyecto en `.agents/skills`, registrada en Git y documentada en `AGENTS.md`. Frontend Design y Web Design Guidelines conservan los Markdown suministrados byte a byte. Taste conserva los 1631 archivos de su carpeta de skill; Apple conserva los 135 archivos originales de su paquete. La comparación de hashes verificó las copias. No se instalaron hooks globales ni se modificaron los scripts originales para alterar los resultados.

Taste se usa como guía de composición y revisión. Las instrucciones explícitas del propietario tienen prioridad sobre sus reglas genéricas: conservar el recorrido WebGL, la identidad monocromática, los contactos reales y la identificación de conceptos. Tampoco se sustituyen las rutas, el backend ni el stack por su starter. El informe del checker conserva los resultados sin convertir esas excepciones en un PASS artificial.

## Validación

`npx tsc --noEmit` y el build de producción terminaron correctamente. `scripts/qa-redesign.mjs`, ejecutado contra el Worker compilado local, completó **66 comprobaciones**, sin errores JavaScript de página. Incluye siete anchos de inicio entre 320 y 1440 px, siete páginas internas a 1440, 768 y 390 px, carga del logo, ausencia de los apartados retirados, redirección antigua, teclado, menú móvil, controles, movimiento reducido, metadatos, enlaces y contenido sin JavaScript. El formulario se probó con un fallo simulado y después con persistencia real en la base local; no se enviaron solicitudes de prueba a producción.

Evidencias: `am-studio-redesign/qa-redesign.json`, capturas en `after/`, comparación antes/después en `comparison-1440.png`, `comparison-768.png` y `comparison-390.png`. La revisión automática de textos produjo cero FAIL y cero WARN en `taste-copy.json`.

Taste final: **GATE: FAIL 57 (round 2 of 3)**, con 17 avisos. Se registran todos los hallazgos y su interpretación en [TASTE-REPORTE.md](TASTE-REPORTE.md); el resultado no se presenta como una aprobación completa. La herramienta de rendimiento del paquete falló internamente en `perf.mjs:416` al leer `first.atEnd.glCreated`, por lo que no produjo una medición válida. Se conserva el log y no se atribuyen cifras de rendimiento a esta entrega.

## Recursos y límites

El video suministrado se revisó como referencia de dispositivos, composición y movimiento; no se publicó como trabajo de AM ni se copiaron sus cifras o marca. No se generaron exportaciones MP4. La fotografía conceptual de Forma, las fuentes y los iconos conservan su procedencia en `ASSETS.md`.

El aviso de privacidad sigue siendo un borrador que requiere los datos y la validación legal del propietario. No se configuraron notificaciones de correo sin una dirección y un proveedor autorizados. Las pruebas locales no equivalen a una certificación WCAG ni a Core Web Vitals de usuarios reales. Las solicitudes publicadas se guardan en D1 y pueden revisarse mediante el acceso autorizado de Sites.

## Ejecutar y restaurar

Node 22.13 o superior: `npm ci`, `npm run dev`. Para revisar el Worker: `npm run build` y `npm run start -- --port 5174`. La comprobación completa acepta `AM_TEST_URL=http://127.0.0.1:5174`. Aplicar la migración local una sola vez según el documento inicial; no repetir una migración aplicada. `AM-ENTREGA.md` se conserva como documento histórico de la primera versión.

El código final se entrega en `AM-Studio-refined-source.zip`, incluyendo las cuatro skills. El archivo inicial `AM-Studio-source.zip` se conserva como respaldo anterior.
