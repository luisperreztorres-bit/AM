# AM Studio — diagnóstico y dirección

Actualización posterior del propietario: integrar el logo oficial suministrado y retirar Mofles Yáñez y “Interfaces que responden”. Estas indicaciones sustituyen las propuestas anteriores sobre esos apartados. El diagnóstico siguiente conserva el contexto de la revisión inicial; la entrega vigente se describe en `REDISENO-ENTREGA.md`.

Tipo: servicios creativos y desarrollo web para negocios. Acción principal: Empezar proyecto.

## Punto de restauración

Tag Git `am-before-refinement-20261109`, commit `a6408e409b8cf362f8792e8b9163949ecb4068ea`. El árbol estaba limpio. Se conservaron capturas de 1440, 768 y 390 px en la carpeta de entrega hermana `am-studio-redesign/before/`.

## Diagnóstico anterior a los cambios

La base funcional es buena: React 19, TypeScript, rutas App Router mediante Vinext, Three.js diferido y formulario D1. No necesita otra arquitectura.

- `src/components/SitePage.tsx`, funciones Hero, Philosophy, Services, Projects y SitePage: los diez títulos principales del inicio incluyen el mismo remate serif; todos usan etiquetas superiores y una composición de titular/promesa parecida. La entrada fade/slide se aplica a casi todas las secciones. Juicio de dirección artística: ese patrón reduce la identidad de AM.
- `src/components/SitePage.tsx`, InterfacePreview y Services: cinco imágenes DOM de la home repiten `architecture.webp`. La misma página conceptual hace de hero, servicio, proyecto y muestra responsive. Los servicios necesitan una demostración propia y el trabajo debe aparecer antes de los experimentos.
- `src/components/SitePage.tsx`, Projects: Mofles Yáñez queda como una nota pequeña. Debe tener un espacio editorial destacado, señalado como caso en preparación y sin inventar capturas ni resultados.
- `src/components/ContactForm.tsx:5` en el commit de restauración: validación nativa y confirmación real correctas, pero no hay errores asociados a cada campo ni spellcheck desactivado en correo.
- `src/components/MotionLab.tsx:6`: las pestañas carecen de navegación con flechas y panel asociado; la reproducción necesita responder a cambios de movimiento reducido y visibilidad de pestaña.
- `app/globals.css`: hay `transition:all` en el visual de servicios y `outline:none` sin tratamiento de grupo en el buscador de comandos. El recorrido y algunos controles del laboratorio tienen objetivos táctiles de 36–38 px; la captura móvil detectó 24 enlaces o controles por debajo de 40 px.
- `src/components/SitePage.tsx` y `MotionLab.tsx`: imágenes sin atributos de dimensiones; tipografía secundaria de 7–12 px en demasiados lugares.

Fuentes: skills originales Frontend Design y Taste; Apple `buttons.md › Best practices`, `motion.md › Best practices`, `typography.md › Ensuring legibility`, `text-fields.md › Best practices`; [Web Interface Guidelines](https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md), consultadas en esta revisión. Es un diagnóstico de desarrollo, no una certificación WCAG.

## Dirección elegida

Una mesa de trabajo digital: la web como objeto central, apoyada en un dispositivo convincente, con tipografía directa y un contraste tipográfico reservado a la frase de marca. Se descarta repetir la cursiva como recurso para todos los títulos. La página muestra el producto de AM — páginas web — y no fotografías de oficinas o personas ajenas.

Color: negro `#0A0A0A`, blanco `#FFFFFF`, superficie `#F0F1F2`, texto `#181818`, secundario `#626469`, línea `#D5D8DC`. Se conserva la identidad monocromática solicitada. Geist para interfaz y títulos; Instrument Serif para la frase completa de marca, sin fragmentar cada título.

Escritorio:

```text
AM Studio      Servicios Proyectos Experiencia Nosotros    Empezar proyecto
Diseño web.                Laptop / interfaz original
Hecho para                 Vista de escritorio + móvil
tu negocio.                Control de presentación
Descripción + contacto     Concepto identificado
```

Móvil: nombre y menú, categoría y titular, descripción y CTA, dispositivo completo y selector táctil. Sin escalar un collage de escritorio hasta volverlo ilegible.

Composición por contenido: filosofía como texto editorial y mapa real de navegación; portafolio como caso pendiente destacado y dos exploraciones diferenciadas; servicios como lista interactiva con una interfaz por servicio; 3D como demostración controlada; proceso como secuencia; laboratorio como banco de pruebas; responsive como cambio real de distribución; FAQ como preguntas accesibles.

Movimiento: una entrada del hero, transformaciones controladas al cambiar la vista del dispositivo, feedback breve de hover/press, continuidad del recorrido y estados del laboratorio. Se retiran las entradas genéricas de cada bloque. Conservar pausa, reinicio, seek y scroll voluntario del 3D. No hay scroll hijacking.

Voz: español directo de un estudio web. Nombres concretos — web, negocio, página, contenido, contacto — y acciones consistentes. Sin cifras, pruebas sociales ni promesas de respuesta inventadas. El video suministrado se usa como referencia de composición y movimiento, sin copiar sus textos, cifras, marca ni contenido comercial al sitio.

## Skills y compatibilidad

Frontend Design y Web Design Guidelines se copiaron byte a byte desde los Markdown suministrados. Taste se extrajo de forma segura, conservando 1631 archivos de su carpeta de skill. Apple se completó con el ZIP encontrado en Descargas, incluyendo AGENTS y referencias. No se ejecutaron instaladores remotos ni scripts de regeneración de referencias de Apple. Las skills quedan en `.agents/skills`, disponibles para descubrimiento en turnos posteriores; en esta revisión se leen directamente.

Se omiten las reglas de Taste que sustituirían rutas por anclas, contactos reales por `.example`, backend por mailto, conceptos por aparentes entregas a clientes o toda la arquitectura por su starter. Se respetan la prioridad y las excepciones pedidas por el usuario. No se cambian los originales del kit para obtener un resultado artificial del checker.
