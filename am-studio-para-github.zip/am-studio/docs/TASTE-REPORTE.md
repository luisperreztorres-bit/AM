GATE: FAIL 57 (round 2 of 3)

# Resultado de Taste

Prueba contra el Worker compilado en localhost:5174. Resultado real, sin waivers ni modificaciones del kit. No se presenta como PASS. Informe íntegro: `qa/taste-gate.json`.

AM: service / other. Dirección elegida a partir del brief: monocromo, Geist e Instrument Serif, interfaz web original en dispositivos, hero con entrada propia y recorrido Three.js solicitado. No se tomó una paleta aleatoria ni se sustituyó la arquitectura por el starter de Taste.

La prioridad explícita del propietario exige conservar el 3D, contactos reales y conceptos identificados. Las reglas de contactos ficticios, ausencia de WebGL, altura exacta por pantalla y clases propias del starter no se aplican como condiciones de publicación. No se ocultan sus resultados.

Interpretación de hallazgos: el análisis shader-lint interpreta tipos GLSL (`sampler3D`, `sampler2DShadow`) e instrucciones include de Three.js como nombres ilegales; las capturas y el control determinista verifican la escena en Chromium. La detección de entrada requiere `data-enter` del kit y no reconoce la animación CSS existente. La búsqueda de foco del input no reconoce el foco visible de su contenedor. Las alertas de spill incluyen el solapamiento intencional entre móvil y laptop; no equivalen a overflow de documento, comprobado en siete anchos.

Límites conservados: el checker señala contraste 4.4:1 en una etiqueta sobre el 3D, recortes y solapamientos en las interfaces conceptuales reducidas, ausencia de un fallback fotográfico ante un fallo de shaders y diferencias de ritmo, escala y alineación respecto a su sistema. Estos avisos permanecen abiertos; las pruebas funcionales no son una certificación de accesibilidad ni una aprobación completa de Taste.

## Los 57 FAIL abiertos

| Regla | Elemento | Hallazgo | Anchos |
|---|---|---|---|
| shader-lint | chunks/three.module-DEFJnE4r.js "sampler3D" | a shader uses "sampler3D" as a name (line 2: uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];): GLSL ES reserves it, so a strict GPU rejects the whole shader and the picture stays empty | 1440 |
| shader-lint | chunks/three.module-DEFJnE4r.js "sampler2DShadow" | a shader uses "sampler2DShadow" as a name (line 11: uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];): GLSL ES reserves it, so a strict GPU rejects the whole shader and the picture stays empty | 1440 |
| shader-lint | chunks/three.module-DEFJnE4r.js "common" | a shader uses "common" as a name (line 2: #include <common>): GLSL ES reserves it, so a strict GPU rejects the whole shader and the picture stays empty | 1440 |
| spill | section.hero > div.hero-layout > div.hero-stage > div.hero-phone "forma® Estudio Proyectos Contacto ↗ El e" | runs 83px past the right edge of the panel it sits on (div.hero-laptop > div.hero-browser > div.interface-preview > div.forma-hero) | 1440, 390 |
| spill | section.hero > div.hero-layout > div.hero-stage > div.hero-view-control "Escritorio Móvil" | runs 44px past the bottom edge of the panel it sits on (div.hero-layout > div.hero-stage > div.hero-laptop > div.laptop-base) | 1440 |
| overlap-text | section.hero > div.hero-layout > div.hero-stage > div.hero-phone "forma® Estudio Proyectos Contacto ↗ El e" | lies over the text "Explorar espacios ↓" (div.forma-hero > span.forma-scroll) | 1440, 390 |
| no-visual | section#filosofia "Tu idea, en marcha." | no picture, effect or mock in this section; a feature section needs a visual | 1440, 390 |
| no-visual | section#servicios "Una página para cada etapa." | no picture, effect or mock in this section; a feature section needs a visual | 1440, 390 |
| no-visual | section#proceso "De la conversación a la publicación." | no picture, effect or mock in this section; a feature section needs a visual | 1440, 390 |
| no-visual | main#main > section.responsive-section.section "Tu web, en cada pantalla." | pictures, effects and mocks cover 10% of this section; a feature section needs a visual (about 25% or more) | 1440, 390 |
| text-only | main#main > section.section.faq "Antes de encargar tu web." | the section is only text: no picture, icon, mock or effect in it (2 sections like it at this width) | 1440, 390 |
| text-only | main#main > section.final-cta "Tu proyecto empieza con una conversación" | the closing section is only text: no picture, icon, mock or effect in it (2 sections like it at this width) | 1440, 390 |
| same-action | header.header > div.header-inner > a.nav-cta "Empezar proyecto" | "Empezar proyecto" appears 3 times in different looks: soft, outline #525252 and soft, fill #ffffff | 1440, 390 |
| copy-fact | h1#hero-heading "Diseño web. Hecho para tu negocio." | the first screen holds no number, price, date, place, platform or genre | 1440 |
| copy-headings | section#filosofia > div.philosophy-grid > div:nth-of-type(1) > h2 "Tu idea, en marcha." | "Tu idea, en marcha." names no product, part, place or section (6 headings like it; at most one brand line per page) (and 5 more like it: "Landing pages +", "De la conversación a la ", "Descubrimiento", "Revisión", ...) | 1440 |
| heading-scale | section#filosofia > div.philosophy-grid > div:nth-of-type(1) > h2 "Tu idea, en marcha." | an h2 at 96.8px, as large as the h1 (90px) or larger | 1440, 390 |
| heading-scale | div.responsive-document > div.responsive-content > div > h3 "Una web que se adapta." | h3 headings in 3 sizes, 24px ("Páginas web corporativas") to 40px (x1.67) | 1440, 390 |
| right-edge | section.hero > div.hero-layout > div.hero-stage > div.hero-phone "forma® Estudio Proyectos Contacto ↗ El e" | its right edge runs 12px past the content's right edge (1376px, where 3 boxes end) | 1440 |
| tilt | section.hero > div.hero-layout > div.hero-stage > div.hero-laptop "forma.concept ↗ forma® Estudio Proyectos" | turned in 3D (and 2 more like it: "forma® Estudio Proyectos", "forma.concept ↗ forma® E") | 1440, 390 |
| contrast | section#recorrido > div.flyover-frame > div.flyover-mode > label "Vincular al scroll" | body text over a effect reads at 4.4:1 at its worst tenth (needs 4.5:1) | 1440, 390 |
| effects-fit | (the page) | a service page asks for 1 WebGL context (div.flyover-canvas, canvas): shader effects are for tech, software, AI and gaming pages | 1440 |
| phone-number | main#main > section.final-cta > div.final-cta-action > a.cta-whatsapp "https://wa.me/522221055229?text=Hola%20A" | a WhatsApp link calls a number in a real dialable format: "https://wa.me/522221055229?text=Hola%20A"; a visitor can dial it and reach a stranger (and 1 more like it: div.footer-top > div.footer-social > div.social-links > a:nth-of-type(3)) | 1440 |
| section-tile | section#filosofia "Tu idea, en marcha." | the section is 699px tall (0.78 screens at 1440x900), shorter than the screen: its tile (the screen from its top) shows 618px of it and 201px of the next section, its heading "El trabajo toma forma." on screen | 1440 |
| section-tile | section#proyectos "El trabajo toma forma." | the section is 1094px tall (1.22 screens at 1440x900), not one screen or two: the screen one screen on from its top (scroll 2500px) shows 112px of it and 707px of the next section, its heading "Una página para cada etapa." on screen | 1440 |
| section-tile | section#proceso "De la conversación a la publicación." | the section is 965px tall (1.07 screens at 1440x900), not one screen or two: the screen one screen on from its top (scroll 5597px) shows none of it and 819px of the next section, its heading "Tu web, en cada pantalla." on screen | 1440 |
| field-label | section#recorrido > div.flyover-frame:nth-of-type(2) > div.flyover-controls:nth-of-type(4) > input | a input[type=range] without a label you can see: only an aria-label names it | 1440 |
| focus-ring | .command-content input:focus-visible | ".command-content input:focus-visible" in index.DIqQWTHQ.css removes the focus outline and sets nothing in its place | 1440 |
| hero-enter | main#main > section.hero | the hero does not enter on load: no data-enter on the hero and no head line setting html.m-enter (motion.md, The hero's entrance) | 1440 |
| moment-none | (the page) | a service page (--type) deals no moment: every kind carries one, two on a long page (moments.md) | 1440 |
| gl-fallback | section#recorrido > div.flyover-frame > div.flyover-canvas "Una web, por dentro." | with its shader rejected (as a strict GPU rejects a reserved word) the WebGL picture shows only the ground its stylesheet gives it (the same pixels with the canvas taken away): it needs a still fallback picture, not a bare gradient | 1440 |
| section-height | footer.footer "StudioEstudio de diseñoy desarrollo web." | the section is 370px tall (0.4 screens), 530px short of one screen (900px): every section after the hero is one screen or two, 2px either way (SR-2) | 1440 |
| section-height | main#main > section.final-cta "Hablemos de tu próxima web.Tu proyectoem" | the section is 475px tall (0.5 screens), 425px short of one screen (900px): every section after the hero is one screen or two, 2px either way (SR-2) | 1440 |
| section-height | section#recorrido "La experiencia AMUna web,por dentro.Reco" | the section's content does not fit it: its lowest content ends 1065px below its top, past 1038px (the section less 72px of bottom padding) (SR-2) | 1440 |
| one-section | main#main > section.section.faq > div:nth-of-type(1) > h2 "Antes de encargartu web." | the screen at scroll 6300px (stride 7) shows 383px of section 8 and the heading of section 8 whole and the content of 2 sections, over 24px each beside section 7: a screen shows one section (another may peek 8px, 24px WARN) (SR-4) | 1440 |
| one-section | footer.footer "StudioEstudio de diseñoy desarrollo web." | the screen at scroll 7500px (the top of section 9) shows 370px of section 10 and the content of 2 sections, over 24px each beside section 9: a screen shows one section (another may peek 8px, 24px WARN) (SR-4) | 1440 |
| container-edges | main#main > section.hero "AM Studio · Diseño y desarrollo webDiseñ" | the content of section 1 runs 64px from the left and 52px from the right (read from its outermost blocks: no .wrap): 64 and 52px are not one margin (one container, equal margins, 2px either way) (SR-6) | 1440 |
| container-edges | a.skip-link "Saltar al contenido" | a <a> at the top of the page, outside header.nav, main, footer.closing and nav.actionbar (SR-6) | 1440 |
| container-edges | header.header "StudioServiciosProyectosExperienciaNosot" | a <header> at the top of the page, outside header.nav, main, footer.closing and nav.actionbar (and 11 more like it: "StudioEstudio de diseñoy", "AM Studio · Diseño y des", "El estudioTu idea,en mar") (SR-6) | 1440 |
| container-edges | section#recorrido > div.flyover-frame > div.flyover-canvas > canvas | the <canvas> runs 0-1440px, outside the container lines of section 5 at 64-1376px: full width is for background layers and grounds only (SR-6) | 1440 |
| container-edges | section#recorrido > div.flyover-frame "Studio / Tu idea, en marcha.Tu negocio m" | a box runs 0-1440px, outside the container lines of section 5 at 64-1376px: full width is for background layers and grounds only (SR-6) | 1440 |
| container-edges | section#recorrido > div.flyover-frame > div.flyover-mode > label "Vincular al scroll" | 1 text block starts on a left line at x 1253, 1189px from the container's left: text starts on the container's left, or on one split line (x 621, 732, 843) (and 10 more like it: x 1208, x 1130, x 1086) (SR-6) | 1440 |
| container-edges | main#main > section.responsive-section.section > p.demo-disclaimer "Mismo contenido. Distribución real con C" | "Mismo contenido. Distribución re" is set centred across 1312px, over half the 1312px container: text that wide is set left (SR-6) | 1440 |
| row-lines | section#recorrido > div.flyover-frame > div.flyover-canvas > canvas | the <canvas> ends at 1440px, past the container's right line at 1376px (SR-7) | 1440 |
| split-pair | section#filosofia > div.philosophy-grid "El estudioTu idea,en marcha.Una página t" | the two columns of the split start 48px apart at the top: a split's columns are top-aligned, 8px either way (SR-8) | 1440 |
| split-pair | div.responsive-stage > div.responsive-window.viewport-desktop > div.responsive-document > div.responsive-content "Forma / versión responsiveUna web quese " | the two columns of the split start 26px apart at the top (centred on each other): a split's columns are top-aligned, 8px either way (SR-8) | 1440 |
| split-pair | section#servicios > div.services-grid "Páginas web corporativas−Presenta tus se" | the split's left column starts with a picture or a box, not text: text left, the visual right, on every split (SR-8) | 1440 |
| split-pair | main#main > section.hero > div.hero-layout "AM Studio · Diseño y desarrollo webDiseñ" | the split's columns are off the page's one pair of lines: its right column starts at x 575, on none of the split lines 626 (k=5), 738 (k=6), 850 (k=7) (SR-8) | 1440 |
| overlap-text | div.project-grid > a.project-card.project-card-0 > div.project-art > span.project-open | lies over the text "Estudio Proyectos Contacto ↗" (div.forma-nav > span) | 390 |
| cut-text | div.project-art > div.interface-preview > div.browser-top > b "↗" | cut 10px at the top by the overflow of section#proyectos > div.project-grid > a.project-card.project-card-0 > div.project-art | 390 |
| cut-text | div.service-visual.service-visual-0 > div.service-document.service-document-0 > div.service-document-foot > span:nth-of-type(2) "AM" | cut 4px at the bottom by the overflow of section#servicios > div.services-grid > div.service-visual.service-visual-0 > div.service-document.service-document-0 | 390 |
| no-visual | main#main > section.hero "Diseño web. Hecho para tu negocio." | pictures, effects and mocks cover 11% of this section; a feature section needs a visual (about 25% or more) | 390 |
| no-visual | section#proyectos "El trabajo toma forma." | pictures, effects and mocks cover 14% of this section; a feature section needs a visual (about 25% or more) | 390 |
| off-grid | div.hero-layout > div.hero-stage > div.hero-laptop > div.hero-browser "forma.concept ↗ forma® Estudio Proyectos" | left edge at 17px, 7px off the page margin at 24px (62 elements, like span.hero-concept-label); 1 more in this section off the grid too (div.laptop-base at 5.5px) | 390 |
| off-grid | section#recorrido > div.flyover-frame > div.flyover-controls "▶ 0.0 / 14.5 s ↺" | left edge at 20px, 4px off the page margin at 24px (62 elements, like span:nth-of-type(1)) | 390 |
| right-edge | div.hero-layout > div.hero-stage > div.hero-laptop > div.laptop-base | its right edge runs 12px past the content's right edge (366px, where 4 boxes end) (and 1 more like it: "▶ 0.0 / 14.5 s ↺") | 390 |
| visual-caption | div.hero-phone > div.interface-preview.phone-view > div.forma-hero > span.forma-caption "ARQUITECTURA CON INTENCIÓN" | a line marked as a caption sits 3px under the picture architecture.webp (its class names it one): "ARQUITECTURA CON INTENCIÓN"; no caption or description under any image, render or visual (house rule) | 390 |
| container | page | no .wrap | 1440, 390 |

## 17 avisos no bloqueantes

- no-visual: main#main > section.hero "Diseño web. Hecho para tu negocio." — pictures, effects and mocks cover 15% of this section; a feature section needs a visual (about 25% or more)
- no-visual: section#proyectos "El trabajo toma forma." — pictures, effects and mocks cover 16% of this section; a feature section needs a visual (about 25% or more)
- copy-buttons: header.header > div.header-inner > a.nav-cta "Empezar proyecto" — "Empezar proyecto" does not start with a verb (book, buy, try, start, get, see...)
- col-edge: main#main > section.hero > div.hero-layout > div.hero-stage "Forma / concepto del estudio forma.conce" — the second column starts at 3 places: 575px (section.hero), 770px (section#filosofia, section#servicios), 1102px (section#proyectos, section.responsive-section.section)
- body-size: section#proceso > div.process-list > div.process-step:nth-of-type(1) > p "Escuchamos tu idea. Entendemos tu negoci" — 5 of 9 paragraphs of running text are set under 16px (15px)
- section-gaps: main#main > section.final-cta / footer.footer — 153px between these sections, -32% against the median 226px
- section-gaps: main#main > section.hero / section#filosofia — uneven space at the edge of a band: 130px outside its edge, 41px inside it (the space on either side of a change of ground reads as one gap only when the two match)
- section-gaps: section#recorrido / section#proceso — uneven space at the edge of a band: 120px outside its edge, 45px inside it (the space on either side of a change of ground reads as one gap only when the two match)
- photo-repeat: div.project-art > div.interface-preview > div.forma-hero > img "architecture.webp" — the photograph architecture.webp is shown 3 times on the page: a picture the visitor has already seen
- one-screen: section#filosofia "Tu idea, en marcha." — 2 sections are shorter than the screen, so the next one's heading or picture shows with them: "Tu idea, en marcha." is 699px of the 819px under the nav, and "El trabajo toma forma." shows below it ("Tu proyecto empieza ")
- visual-caption: section#recorrido > div.flyover-foot > span:nth-of-type(1) "Forma es un concepto propio de AM." — a muted 12px line of 1 row sits 12px under the canvas: it reads as a caption: "Forma es un concepto propio de AM."; no caption or description under any image, render or visual (house rule)
- cut-text: div.interface-preview.phone-view > div.forma-hero > div.forma-headline > i "se siente." — sits across the edge of a panel behind it
- body-size: section.hero > div.hero-layout > div.hero-copy > p:nth-of-type(2) "Diseñamos páginas que explican lo que ha" — 6 of 9 paragraphs of running text are set under 16px (15px)
- section-gaps: main#main > section.section.faq / main#main > section.final-cta — 179px between these sections, +40% against the median 128px of gaps at a change of ground
- photo-repeat: div.responsive-window.viewport-desktop > div.responsive-document > div.responsive-content > img "architecture.webp" — the photograph architecture.webp is shown 2 times on the page: a picture the visitor has already seen
- section-tile: section#filosofia "Tu idea, en marcha." — the section is 795px tall (0.94 screens at 390x844), shorter than the screen: its tile (the screen from its top) shows 721px of it and only 50px of the next section's ground ("El trabajo toma forma."), none of its content
- fold-cut: div.hero-browser > div.interface-preview > div.forma-hero > div.forma-headline "El espacio también se siente." — a line of the hero text is sliced by the bottom of the first screen

No se aplicaron waivers. Los originales de las skills se conservan intactos.

La comprobación de rendimiento `perf.mjs` terminó con un error interno en la línea 416 (`first.atEnd` no definido). No hay resultado de rendimiento válido. Log: `qa/taste-perf-error.txt`. No se modificó el script para ocultarlo.
