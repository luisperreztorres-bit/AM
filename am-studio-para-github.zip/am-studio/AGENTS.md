# AM Studio — instrucciones del proyecto

Trabajar sobre este proyecto existente. Conservar sus rutas, formulario D1, identidad comercial, redes oficiales, recorrido Three.js y demostración responsive. No iniciar otro Site ni sustituir el proyecto por un starter.

## Skills de diseño del proyecto

Consultar antes de proponer o modificar diseño:

- `.agents/skills/frontend-design/SKILL.md`: dirección artística, identidad, estructura, tipografía y eliminación de composiciones genéricas.
- `.agents/skills/design-taste-frontend/SKILL.md`: composición, contenido, ritmo, imágenes, movimiento y herramientas de revisión. Se conserva el paquete completo con referencias, recursos y scripts. Inspeccionar scripts y dependencias antes de ejecutarlos.
- `.agents/skills/web-design-guidelines/SKILL.md`: auditar interacción, semántica, accesibilidad, formularios, navegación y rendimiento. Consultar las pautas actualizadas de su origen y citar archivos y líneas reales.
- `.agents/skills/apple-design/SKILL.md`: claridad, jerarquía, legibilidad, consistencia y movimiento con propósito. Traducir los principios al navegador, sin reproducir controles nativos por apariencia.

Prioridad: instrucciones del usuario e identidad de AM; funcionalidades existentes; accesibilidad y estabilidad; calidad visual; recomendaciones de las skills.

## Adaptación de Taste a AM

AM es una empresa de servicios creativos y desarrollo web (`service` / `other`), no una tienda o un producto SaaS. Su brief solicita expresamente demos 3D y controles interactivos: mantenerlos aunque las reglas generales de Taste limiten WebGL para servicios. Conservar las URLs, WhatsApp y backend reales; no sustituirlos por contactos `.example`, enlaces de ancla ni mailto de demostración. Los conceptos deben identificarse como tales. No ocultar esa información para superar un checker. No fijar cada sección a múltiplos exactos de la pantalla cuando cause espacio vacío, recorte, solapamiento o pérdida de contenido al ampliar texto.

No instalar hooks de otras aplicaciones, cambiar el stack, aplicar paletas aleatorias, copiar el starter ni cargar todo el kit en producción. Mantener intactos los archivos originales de las skills. Documentar recomendaciones incompatibles y resultados reales, incluidos errores o límites de herramientas.

## Trabajo y validación

Crear un punto de restauración antes de una revisión importante. Inspeccionar antes de editar, registrar diagnóstico, definir dirección visual y comparar capturas antes/después. Usar Playwright y las comprobaciones de Taste que sean compatibles. Verificar escritorio, tablet, móvil, teclado, movimiento reducido, enlaces y estados de formulario. No afirmar cumplimiento o pruebas que no se hayan ejecutado. Las notas de diseño y QA van en `docs/`; los temporales en `work/`. Mantener `.openai/hosting.json` y el mismo Site y audiencia.

No inventar clientes, resultados, métricas, ubicación, plazos, precios, testimonios ni datos legales. El logo oficial fue suministrado y debe conservar su geometría. Por petición posterior del propietario, no publicar el apartado de Mofles Yáñez ni el laboratorio “Interfaces que responden”. Esta instrucción posterior tiene prioridad sobre el brief anterior.
