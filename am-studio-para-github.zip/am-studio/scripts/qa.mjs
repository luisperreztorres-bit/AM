import {chromium} from '@playwright/test';
import {mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
const base=process.env.AM_TEST_URL||'http://127.0.0.1:5173';
const out=path.resolve('../am-studio-qa');await mkdir(out,{recursive:true});
const browser=await chromium.launch({headless:true});
const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:2});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
const report={routes:[],viewports:[],checks:[],errors};
const assert=(condition,message)=>{if(!condition)throw new Error(message);report.checks.push(message);console.log('PASS',message)};
try{
  await page.goto(base+'/demo/forma',{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);await page.locator('img').evaluateAll(images=>{images.forEach(i=>i.loading='eager');return Promise.all(images.map(i=>i.decode()))});
  const layers=await page.locator('[data-layer]').evaluateAll(els=>els.map(e=>{const r=e.getBoundingClientRect();return{layer:e.dataset.layer,x:r.x,y:r.y,width:r.width,height:r.height}}));
  for(const layer of layers){const layerBuffer=await page.locator(`[data-layer="${layer.layer}"]`).screenshot({type:'png'});await sharp(layerBuffer).resize({width:Math.round(layer.width)}).webp({quality:92}).toFile(`public/images/forma-layer-${layer.layer}.webp`);}
  await writeFile('public/images/forma-layers.json',JSON.stringify({viewport:1440,deviceScaleFactor:2,layers},null,2));
  const buffer=await page.locator('.capture-page').screenshot({type:'png'});await sharp(buffer).resize({width:1440}).webp({quality:92}).toFile('public/images/forma-page.webp');
  await page.goto(base,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
  for(const width of [1440,1280,768,390,360]){await page.setViewportSize({width,height:1000});await page.goto(base,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(1200);const geometry=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,hero:document.querySelector('h1').getBoundingClientRect().toJSON()}));assert(geometry.scroll<=width,`Sin overflow horizontal en ${width}px`);await page.screenshot({path:path.join(out,`home-${width}.png`)});report.viewports.push(geometry);}
  await page.setViewportSize({width:1440,height:1000});
  for(const route of ['/servicios','/proyectos','/experiencia','/nosotros','/contacto','/privacidad','/proyectos/forma','/proyectos/interface-lab']){const response=await page.goto(base+route,{waitUntil:'networkidle'});assert(response.status()===200,`Ruta ${route} devuelve 200`);assert(await page.locator('h1').count()===1,`Un título principal en ${route}`);report.routes.push({route,status:response.status()});}
  await page.goto(base+'/servicios',{waitUntil:'networkidle'});await page.getByRole('button',{name:'Landing pages'}).click();assert(await page.locator('#service-1').isVisible(),'Acordeón de servicios funcional');
  await page.goto(base+'/experiencia',{waitUntil:'networkidle'});
  await page.locator('.flyover-frame').scrollIntoViewIfNeeded();await page.waitForFunction(()=>!!window.amFlyover,{timeout:30000});
  for(const t of [0,1.6,2.5,5,6.5,9.3,11]){await page.evaluate(t=>window.amFlyover.seek(t),t);await page.waitForTimeout(80);await page.locator('.flyover-frame').screenshot({path:path.join(out,`flyover-${t}.png`)});}
  const trajectory=await page.evaluate(()=>Array.from({length:831},(_,i)=>window.amFlyover.frameAt(i/100).travel));assert(trajectory.every((v,i)=>!i||v>=trajectory[i-1]-1e-9),'Trayectoria longitudinal sin inversiones');
  await page.goto(base+'/contacto',{waitUntil:'networkidle'});await page.getByRole('button',{name:'Enviar solicitud'}).click();assert(await page.locator('.form-message.success').count()===0,'Formulario vacío no muestra éxito');
  await page.locator('[name=name]').fill('Prueba QA AM');await page.locator('[name=business]').fill('Validación local, no cliente');await page.locator('[name=email]').fill('qa@example.invalid');await page.locator('[name=pageType]').selectOption({label:'Landing page'});await page.locator('textarea[name=description]').fill('Solicitud de prueba automatizada local para verificar persistencia real del formulario.');await page.locator('[name=consent]').check();await page.getByRole('button',{name:'Enviar solicitud'}).click();await page.locator('.form-message.success').waitFor({timeout:20000});assert(await page.locator('.form-message.success').isVisible(),'Solicitud confirmada por backend tras guardar en D1');
  const invalid=await page.evaluate(async()=>{const r=await fetch('/api/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:'x'})});return r.status});assert(invalid===400,'Backend rechaza payload inválido');
  const links=await page.locator('.social-links a').evaluateAll(els=>els.map(e=>({href:e.href,target:e.target,rel:e.rel})));assert(links.every(l=>l.target==='_blank'&&l.rel.includes('noopener')),'Redes abren en nueva pestaña con noopener');assert(links.some(l=>l.href.startsWith('https://wa.me/522221055229?text=')),'WhatsApp usa número oficial y mensaje codificado');
  await page.setViewportSize({width:390,height:844});await page.goto(base,{waitUntil:'networkidle'});await page.getByRole('button',{name:'Abrir menú'}).click();assert(await page.locator('#mobile-nav').isVisible(),'Menú móvil abre');await page.keyboard.press('Escape');assert(await page.locator('#mobile-nav').isHidden(),'Escape cierra menú móvil');await page.keyboard.press('Tab');
  await page.emulateMedia({reducedMotion:'reduce'});assert(await page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches),'Preferencia de movimiento reducido disponible');
  assert(errors.length===0,'Sin errores JavaScript de página');
  await writeFile(path.join(out,'qa-report.json'),JSON.stringify(report,null,2));console.log('QA completa:',report.checks.length,'comprobaciones');
}catch(e){report.failure=e.stack;await page.screenshot({path:path.join(out,'failure.png'),fullPage:true});await writeFile(path.join(out,'qa-report.json'),JSON.stringify(report,null,2));console.error(e);process.exitCode=1}finally{await browser.close()}
