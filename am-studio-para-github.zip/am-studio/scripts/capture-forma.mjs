import {chromium} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
import sharp from 'sharp';
const browser=await chromium.launch();
try{
  const page=await browser.newPage({viewport:{width:1440,height:1152},deviceScaleFactor:2});
  await page.goto((process.env.AM_TEST_URL||'http://127.0.0.1:5173')+'/demo/forma',{waitUntil:'networkidle'});
  await page.evaluate(()=>document.fonts.ready);
  await page.locator('img').evaluateAll(images=>{images.forEach(i=>i.loading='eager');return Promise.all(images.map(i=>i.decode()))});
  const layers=await page.locator('[data-layer]').evaluateAll(els=>els.map(e=>{const r=e.getBoundingClientRect();return{layer:e.dataset.layer,x:r.x,y:r.y,width:r.width,height:r.height}}));
  for(const layer of layers){const image=await page.locator(`[data-layer="${layer.layer}"]`).screenshot({type:'png'});await sharp(image).resize({width:Math.round(layer.width)}).webp({quality:92}).toFile(`public/images/forma-layer-${layer.layer}.webp`)}
  await writeFile('public/images/forma-layers.json',JSON.stringify({viewport:1440,deviceScaleFactor:2,layers},null,2));
  const image=await page.locator('.capture-page').screenshot({type:'png'});await sharp(image).resize({width:1440}).webp({quality:92}).toFile('public/images/forma-page.webp');
  console.log('Forma actualizada: página y',layers.length,'capas medidas.');
}finally{await browser.close()}
