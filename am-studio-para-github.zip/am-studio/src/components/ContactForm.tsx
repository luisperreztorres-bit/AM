'use client';
import { useEffect, useRef, useState } from 'react';
import { whatsappUrl } from '../config/brand';
import { Arrow } from './Icons';

const fieldNames = ['name','business','email','phone','pageType','budget','description','consent'] as const;
type FieldName = typeof fieldNames[number];
type FieldErrors = Partial<Record<FieldName,string>>;
const labels: Record<FieldName,string> = {name:'Tu nombre',business:'Nombre del negocio',email:'Correo electrónico',phone:'WhatsApp',pageType:'Tipo de página',budget:'Presupuesto',description:'Descripción del proyecto',consent:'Consentimiento'};

export function ContactForm() {
  const formRef = useRef<HTMLFormElement>(null);
  const statusRef = useRef<HTMLDivElement>(null);
  const [status,setStatus] = useState<'idle'|'loading'|'success'|'error'>('idle');
  const [error,setError] = useState('');
  const [fieldErrors,setFieldErrors] = useState<FieldErrors>({});
  const [receipt,setReceipt] = useState('');
  const [waMessage,setWaMessage] = useState('');
  const [dirty,setDirty] = useState(false);

  useEffect(() => {
    if(!dirty || status==='success') return;
    const warn = (event:BeforeUnloadEvent) => {event.preventDefault();event.returnValue='';};
    window.addEventListener('beforeunload',warn);
    return () => window.removeEventListener('beforeunload',warn);
  },[dirty,status]);

  function validate(form:HTMLFormElement) {
    const errors:FieldErrors={};
    for(const name of fieldNames) {
      const field=form.elements.namedItem(name) as HTMLInputElement|HTMLSelectElement|HTMLTextAreaElement;
      const value=field.value.trim();
      if(name==='consent') {
        if(!(field as HTMLInputElement).checked) errors[name]='Lee la información de privacidad y marca tu consentimiento para enviar la solicitud.';
      } else if(field.required && !value) {
        errors[name]=name==='pageType'?'Selecciona el tipo de página que necesitas.':`Completa el campo ${labels[name].toLowerCase()}.`;
      } else if(name==='email' && (!field.validity.valid || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))) {
        errors[name]='Escribe un correo con este formato: nombre@correo.com.';
      } else if(name==='phone' && value && !/^[+0-9 ()-]{7,25}$/.test(value)) {
        errors[name]='Escribe entre 7 y 25 caracteres: números, +, espacios, paréntesis o guiones.';
      } else if(name==='description' && value.length<20) {
        errors[name]='Cuéntanos un poco más: escribe al menos 20 caracteres.';
      }
    }
    return errors;
  }

  async function submit(event:React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if(status==='loading') return;
    const form=event.currentTarget;
    const errors=validate(form);
    setFieldErrors(errors);
    if(Object.keys(errors).length) {
      setStatus('error');
      setError('Revisa los campos señalados para enviar tu solicitud.');
      (form.elements.namedItem(Object.keys(errors)[0]) as HTMLElement)?.focus();
      return;
    }
    setStatus('loading');setError('');
    try {
      const response=await fetch('/api/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(form)))});
      const data=await response.json().catch(()=>({})) as {error?:string;id?:string};
      if(!response.ok || !data.id) throw new Error(data.error || 'No pudimos guardar tu solicitud. Intenta nuevamente o escríbenos por WhatsApp.');
      const f=new FormData(form);
      setWaMessage(`Hola AM, envié una solicitud (ref. ${data.id}).\nNombre: ${f.get('name')}\nNegocio: ${f.get('business')}\nCorreo: ${f.get('email')}\nTipo: ${f.get('pageType')}\nPresupuesto: ${f.get('budget')||'-'}\nProyecto: ${f.get('description')}`);
      setReceipt(data.id);setStatus('success');setDirty(false);form.reset();
      requestAnimationFrame(()=>statusRef.current?.focus());
    } catch(failure) {
      setError(failure instanceof Error && failure.name!=='TypeError'?failure.message:'No pudimos conectar con el servidor. Revisa tu conexión e intenta nuevamente, o escríbenos por WhatsApp.');
      setStatus('error');
      requestAnimationFrame(()=>statusRef.current?.focus());
    }
  }

  const accessibility=(name:FieldName)=>({id:'contact-'+name,'aria-invalid':fieldErrors[name]?true:undefined,'aria-describedby':fieldErrors[name]?'error-'+name:undefined});
  const fieldError=(name:FieldName)=>fieldErrors[name]?<span className="field-error" id={'error-'+name}>{fieldErrors[name]}</span>:null;
  return <form ref={formRef} className="contact-form" action="/api/contact" method="post" onSubmit={submit} noValidate onInput={()=>{setDirty(true);if(status==='success')setStatus('idle')}}>
    <noscript><p>Para usar el formulario, activa JavaScript. También puedes <a href={whatsappUrl()} target="_blank" rel="noopener noreferrer">contactar a AM por WhatsApp</a>.</p><style>{'.contact-form .form-grid,.contact-form .consent,.contact-form .form-submit,.contact-form .form-heading,.contact-form .form-footnote{display:none}'}</style></noscript>
    <div className="form-heading"><span>Los detalles de tu proyecto</span><small>* Campos necesarios</small></div>
    <div className="form-grid">
      <label htmlFor="contact-name">Tu nombre *<input {...accessibility('name')} name="name" autoComplete="name" required maxLength={100} placeholder="Tu nombre…"/>{fieldError('name')}</label>
      <label htmlFor="contact-business">Nombre de tu negocio *<input {...accessibility('business')} name="business" autoComplete="organization" required maxLength={150} placeholder="Tu negocio o marca…"/>{fieldError('business')}</label>
      <label htmlFor="contact-email">Correo electrónico *<input {...accessibility('email')} name="email" autoComplete="email" type="email" inputMode="email" spellCheck={false} autoCapitalize="none" required maxLength={254} placeholder="nombre@correo.com…"/>{fieldError('email')}</label>
      <label htmlFor="contact-phone">WhatsApp <span>(opcional)</span><input {...accessibility('phone')} name="phone" autoComplete="tel" type="tel" inputMode="tel" maxLength={25} pattern="[+0-9 ()-]{7,25}" placeholder="+52 222 000 0000…"/>{fieldError('phone')}</label>
      <label htmlFor="contact-pageType">Tipo de página *<select {...accessibility('pageType')} name="pageType" required defaultValue=""><option value="" disabled>Selecciona una opción</option><option>Web corporativa</option><option>Landing page</option><option>Experiencia a medida</option><option>Quiero orientación</option></select>{fieldError('pageType')}</label>
      <label htmlFor="contact-budget">Presupuesto aproximado <span>(opcional)</span><input {...accessibility('budget')} name="budget" autoComplete="off" maxLength={100} placeholder="Monto y moneda, si lo tienes definido…"/>{fieldError('budget')}</label>
      <label className="full-field" htmlFor="contact-description">Háblanos de tu proyecto *<textarea {...accessibility('description')} name="description" autoComplete="off" required minLength={20} maxLength={5000} rows={5} placeholder="Qué hace tu negocio y qué necesitas de tu página…"/>{fieldError('description')}</label>
    </div>
    <label className="honeypot" aria-hidden="true">Sitio web<input name="website" tabIndex={-1} autoComplete="off"/></label>
    <label className="consent" htmlFor="contact-consent"><input {...accessibility('consent')} name="consent" type="checkbox" required value="yes"/><span>Acepto que AM utilice estos datos para responder a mi solicitud. He leído la <a href="/privacidad" target="_blank" rel="noopener noreferrer" aria-label="Información de privacidad (abre en otra pestaña)">información de privacidad</a>. *</span></label>
    {fieldError('consent')}
    <button className="button dark form-submit" type="submit" disabled={status==='loading'} aria-busy={status==='loading'}>{status==='loading'?<><span className="spinner" aria-hidden="true"/>Guardando solicitud…</>:<>Enviar solicitud <Arrow diagonal/></>}</button>
    <div ref={statusRef} tabIndex={-1} aria-live="polite" aria-atomic="true" className="form-status">
      {status==='error'&&<p className="form-message error">{error}</p>}
      {status==='success'&&<div className="form-message success"><b>Tu solicitud quedó guardada.</b><p>Referencia: {receipt}. Último paso: envíala por WhatsApp para que te respondamos más rápido.</p><a className="button dark" href={whatsappUrl(waMessage)} target="_blank" rel="noopener noreferrer">Enviar por WhatsApp ↗</a></div>}
    </div>
    <p className="form-footnote">Usamos esta información para revisar tu proyecto y ponernos en contacto contigo.</p>
  </form>;
}
