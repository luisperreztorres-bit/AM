export const DURATION=14.5;
export const clamp=(x:number,a=0,b=1)=>Math.min(b,Math.max(a,x));
export const smooth=(x:number)=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10)};
export const mix=(a:number,b:number,t:number)=>a+(b-a)*t;
// Integral of quintic smoothstep: zero velocity and acceleration at both ends.
const primitive=(x:number)=>x**6-3*x**5+2.5*x**4;
const rampIntegral=(t:number,a:number,b:number,from:number,to:number)=>{const d=b-a;return from*clamp(t-a,0,d)+(to-from)*d*primitive(clamp((t-a)/d));};
export function travelAt(t:number){return 7.7*(rampIntegral(t,0,.6,0,.5)+rampIntegral(t,.6,1.25,.5,.5)+rampIntegral(t,1.25,1.6,.5,1)+rampIntegral(t,1.6,7.3,1,1)+rampIntegral(t,7.3,8.3,1,0));}
export function frameAt(input:number){const t=clamp(input,0,DURATION),rise=smooth((t-7.75)/1.5),home=smooth((t-9.47)/.5),hold=clamp((t-9.97)/(DURATION-9.97));const z=-4.7-travelAt(t);const targetZ=mix(mix(z,-28,rise),-4.8,home);const distance=Math.exp(mix(mix(Math.log(17),Math.log(74),rise),Math.log(27),home));const angle=mix(mix(56*Math.PI/180,.035,rise),.24,home);return{t,targetZ,cameraY:Math.cos(angle)*distance,cameraZ:targetZ+Math.sin(angle)*distance,trim:smooth((t-9.47)/.5),end:smooth((t-10)/.6),scale:1+hold*.02,travel:travelAt(t)};}
