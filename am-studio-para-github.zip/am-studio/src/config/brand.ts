export const brand = {
  brandName: 'AM Studio', brandTagline: 'Tu idea, en marcha.',
  valueProposition: 'Creamos experiencias digitales a la altura de tu negocio.',
  logo: '/brand/am-logo.svg' as string | null, // Recurso oficial suministrado por el propietario.
  instagram: 'https://www.instagram.com/____amstudio.pue/', tiktok: 'https://www.tiktok.com/@am.estudio_', whatsapp: '522221055229',
  email: null as string | null, website: 'https://am-studio-digital-261110.axialkelp1.chatgpt.site', location: null as string | null,
  services: [
    {title:'Páginas web corporativas',text:'Presenta tus servicios, organiza la información de tu negocio y ofrece un canal directo de contacto.',tags:'Estructura clara · Identidad propia · Contacto directo'},
    {title:'Landing pages',text:'Páginas para una campaña o una oferta: reúne los detalles y el siguiente paso en un solo lugar.',tags:'Campañas · Lanzamientos · Captación'},
    {title:'Experiencias web a medida',text:'Diseñamos interfaces para tu contenido y las acciones que necesita realizar quien visita tu web.',tags:'Diseño de interfaces · Interacción · Motion'},
    {title:'Diseño responsive',text:'Adaptamos la distribución, los textos y los controles para escritorio, tablet y móvil.',tags:'Escritorio · Tablet · Móvil'},
  ],
  projects: [
    {slug:'forma',name:'Forma',category:'Concepto de arquitectura',description:'Una web conceptual de arquitectura, con una imagen original, navegación breve y versión móvil.',type:'Concepto AM · No es un proyecto de cliente'},
  ],
};
export const whatsappUrl = (message='Hola AM Studio, me gustaría hablar de un proyecto web.') => `https://wa.me/${brand.whatsapp}?text=${encodeURIComponent(message)}`;
