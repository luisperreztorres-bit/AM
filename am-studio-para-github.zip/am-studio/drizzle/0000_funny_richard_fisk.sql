CREATE TABLE `inquiries` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`business` text NOT NULL,
	`email` text NOT NULL,
	`phone` text,
	`page_type` text NOT NULL,
	`budget` text,
	`description` text NOT NULL,
	`created_at` integer NOT NULL
);
